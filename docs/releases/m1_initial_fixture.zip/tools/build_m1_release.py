"""Build the M1 offline overlay against the verified GitHub M0 baseline.

No credentials, environments, video sources, model weights, or user data are
included. The existing recoverable installer validates every payload and guard.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
if __package__ in (None, ''):
    sys.path.insert(0, str(ROOT))
from tools import complete_installer as installer


def digest(data):
    return hashlib.sha256(data).hexdigest()


def build(output, source_commit, verification=None):
    if not re.fullmatch(r'[0-9a-f]{40}', source_commit):
        raise ValueError('SHA commit sumber harus lengkap.')
    output = Path(output).resolve()
    archive = output.with_suffix('.zip')
    if output.exists() or archive.exists():
        raise ValueError('Pilih nama paket baru; paket lama tidak ditimpa.')
    baseline = json.loads((ROOT / 'docs/releases/m1_base_hashes.json').read_text())
    output.mkdir(parents=True)
    files = []
    for name in baseline['payload_paths']:
        source = installer.safe_path(ROOT, name)
        data = source.read_bytes()
        dest = installer.safe_path(output / 'payload', name)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        text_hash = digest(data.replace(b'\r\n', b'\n'))
        files.append({'path': name, 'sha256': digest(data), 'text_sha256': text_hash,
            'allowed_text_sha256': sorted(set(baseline['allowed_hashes'].get(name, []) + [text_hash]))})
    guards = [{'path': name, 'allowed_text_sha256': baseline['allowed_hashes'][name]}
              for name in baseline['guard_paths']]
    manifest = {'schema_version': 1, 'version': '4.0.11', 'milestone': 'M1',
        'release_id': 'm1-editor-20261012', 'source_commit': source_commit, 'source_origin': 'local',
        'baseline_github_commit': baseline['base_commit'],
        'accepted_baseline_github_commits': [baseline['base_commit']],
        'requires_installation': 'Clipper Studio 4.0.11 M0 matching GitHub b8c4ce2',
        'install_command': 'PASANG_M1_4_0_11.cmd',
        'offline_update': True, 'files': files, 'guards': guards,
        'data_directories_untouched': ['work', 'clips', 'uploads', '.venv', 'ClipperModels', 'models'],
        'specification_basis': 'Public M1 scope and nine-panel audit from shared chats; 120-page PDF unavailable',
        'pending_acceptance': ['Complete 120-page specification traceability',
            'Actual Windows browser and two-tab acceptance', 'Original-video preview/render on user hardware']}
    (output / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    shutil.copyfile(ROOT / 'tools/complete_installer.py', output / 'complete_installer.py')
    shutil.copyfile(ROOT / 'docs/UPGRADE_4_0_11_M1.md', output / 'PANDUAN_M1.md')
    for name, flag in [('CEK_SEBELUM_UPGRADE.cmd', '--check'),
                       ('PASANG_M1_4_0_11.cmd', ''), ('PULIHKAN_M1_4_0_11.cmd', '--rollback')]:
        command = ('@echo off\r\nsetlocal\r\ncd /d "%~dp0."\r\n'
            'where py >nul 2>nul\r\nif errorlevel 1 (\r\n'
            '  python "%~dp0complete_installer.py" '+flag+' %*\r\n'
            ') else (\r\n  py -3 "%~dp0complete_installer.py" '+flag+' %*\r\n)\r\n'
            'set "RESULT=%ERRORLEVEL%"\r\npause\r\nexit /b %RESULT%\r\n')
        (output / name).write_bytes(command.encode('utf-8'))
    (output / 'BACA_DULU.txt').write_text(
        'CLIPPER STUDIO 4.0.11 M1 - EDITOR, PENCARIAN DAN UNDO/REDO\n\n'
        'Dasar: 4.0.11 M0 dari GitHub b8c4ce2.\n'
        '1. Ekstrak ZIP ke folder baru di luar folder mesin.\n'
        '2. Hentikan antrean, lalu tutup server dengan Ctrl+C.\n'
        '3. Klik CEK_SEBELUM_UPGRADE.cmd; isi lokasi folder mesin lama.\n'
        '4. Jika lulus, klik PASANG_M1_4_0_11.cmd; pilih folder yang sama.\n'
        '5. Jalankan JALANKAN_PRO.cmd dari mesin, lalu Ctrl+F5 di browser.\n'
        '6. Pastikan tulisan versi menjadi 4.0.11 M1. Baca PANDUAN_M1.md.\n\n'
        'Paket memeriksa kode dasar, mencadangkan kode dan SQLite, dan pulih\n'
        'bila pemasangan gagal. Jangan menyalin payload secara manual.\n'
        'Tidak mengunduh model atau memasang dependensi. Video, .env, model,\n'
        'font pribadi dan koreksi proyek tidak ditimpa.\n'
        'Rollback kode: PULIHKAN_M1_4_0_11.cmd. Database tetap menyimpan edit baru.\n'
        'Bukti uji dan batasnya ada pada verification/ dan PANDUAN_M1.md.\n', encoding='utf-8')
    if verification:
        shutil.copytree(verification, output / 'verification')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
        for file in sorted(output.rglob('*')):
            if file.is_file():
                zipped.write(file, output.name+'/'+file.relative_to(output).as_posix())
    with zipfile.ZipFile(archive) as zipped:
        if zipped.testzip():
            raise ValueError('CRC paket gagal.')
        for row in files:
            if digest(zipped.read(output.name+'/payload/'+row['path'])) != row['sha256']:
                raise ValueError('Checksum payload gagal: '+row['path'])
    result = {'archive': str(archive), 'bytes': archive.stat().st_size,
        'sha256': digest(archive.read_bytes()), 'payload_files': len(files), 'guards': len(guards),
        'source_commit': source_commit, 'baseline_github_commit': baseline['base_commit'],
        'milestone': 'M1', 'zip_crc': 'passed'}
    print(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--verification')
    args = parser.parse_args()
    build(args.output, args.source_commit, args.verification)
