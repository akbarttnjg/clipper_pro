"""Stage 3 - the camera operator. Track the speaker and crop to 9:16 smoothly.

The trick that separates this from a jittery mess is *smoothing*: we detect the
face position over time, then run a forward+backward exponential average so the
virtual camera glides instead of snapping on every head twitch.
"""
from __future__ import annotations
import subprocess
from pathlib import Path

import cv2
import numpy as np

from .config import Config
from .ffmpeg_util import even, ass_filter, encoder_args, final_audio_args

# Model installation is explicit. Render helpers only read prepared local files.
_YUNET_PATH = Path(__file__).parent / "models" / "face_detection_yunet.onnx"
_DETECT_W = 640  # downscale frames to this width for face detection (speed)


def _try_yunet(w: int, h: int):
    """Return only prepared local weights; rendering never downloads a model."""
    try:
        if not _YUNET_PATH.exists() or _YUNET_PATH.stat().st_size < 10000:
            return None
        return cv2.FaceDetectorYN.create(str(_YUNET_PATH), "", (w, h), score_threshold=0.6)
    except Exception:
        return None


def _haar():
    """opencv's built-in frontal-face cascade. Bundled with the pip package."""
    if not hasattr(cv2,'CascadeClassifier') or not hasattr(cv2,'data'):return None
    cascade=cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    return None if cascade.empty() else cascade


def _make_detector(w: int, h: int):
    """(detector, kind) where kind is 'yunet' or 'haar'."""
    yn = _try_yunet(w, h)
    if yn is not None:
        return yn, "yunet"
    return _haar(), "haar"


def _largest_center(detector, kind, frame):
    """Return (cx, cy) of the biggest detected face, or None."""
    if detector is None:return None
    if kind == "yunet":
        _, faces = detector.detect(frame)
        if faces is None or not len(faces):
            return None
        f = max(faces, key=lambda f: f[2] * f[3])
        return f[0] + f[2] / 2.0, f[1] + f[3] / 2.0
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector.detectMultiScale(gray, 1.1, 5, minSize=(30, 30))
    if len(faces) == 0:
        return None
    x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
    return x + fw / 2.0, y + fh / 2.0


def _largest_box(detector, kind, frame):
    """Return (x, y, w, h) of the biggest detected face, or None."""
    if detector is None:return None
    if kind == "yunet":
        _, faces = detector.detect(frame)
        if faces is None or not len(faces):
            return None
        f = max(faces, key=lambda f: f[2] * f[3])
        return float(f[0]), float(f[1]), float(f[2]), float(f[3])
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector.detectMultiScale(gray, 1.1, 5, minSize=(30, 30))
    if len(faces) == 0:
        return None
    x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
    return float(x), float(y), float(fw), float(fh)


def _facecam_rect(boxes: list, w: int, h: int, pad: float = 0.5):
    """From sampled face boxes (x,y,fw,fh), return the padded facecam rect (x,y,w,h),
    or None if the faces are too few, too scattered (not a fixed cam), or fill the
    screen (a full-screen face, not a webcam box)."""
    if len(boxes) < 3:
        return None
    arr = np.array(boxes, dtype=float)
    cx, cy = arr[:, 0] + arr[:, 2] / 2, arr[:, 1] + arr[:, 3] / 2
    fw, fh = float(np.median(arr[:, 2])), float(np.median(arr[:, 3]))
    if fw > 0.5 * w:                                  # full-screen face, not a cam
        return None
    mcx, mcy = float(np.median(cx)), float(np.median(cy))
    if np.median(np.abs(cx - mcx)) > fw * 0.6 or np.median(np.abs(cy - mcy)) > fh * 0.6:
        return None                                  # centers don't cluster -> no fixed cam
    rw, rh = fw * (1 + 2 * pad), fh * (1 + 2 * pad)
    rx, ry = mcx - rw / 2, mcy - rh / 2
    rx, ry = max(0.0, min(rx, w - 1.0)), max(0.0, min(ry, h - 1.0))
    rw, rh = min(rw, w - rx), min(rh, h - ry)
    return int(rx), int(ry), int(rw), int(rh)


def detect_facecam(clip_path: str, cfg: Config):
    """Sample frames and locate a stationary webcam box (x,y,w,h), or None. Used by the
    'stream' layout to separate facecam from gameplay in a single source."""
    cap = cv2.VideoCapture(clip_path)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    scale = min(1.0, _DETECT_W / w)
    dw, dh = max(1, round(w * scale)), max(1, round(h * scale))
    detector, kind = _make_detector(dw, dh)
    step = max(1, n // 24)
    boxes, idx = [], 0
    while True:
        if not cap.grab():
            break
        if idx % step == 0:
            ok, frame = cap.retrieve()
            if ok:
                small = cv2.resize(frame, (dw, dh)) if scale < 1.0 else frame
                box = _largest_box(detector, kind, small)
                if box is not None:
                    boxes.append([c / scale for c in box])
        idx += 1
    cap.release()
    return _facecam_rect(boxes, w, h)


def _crop_plan(w: int, h: int, tw: int, th: int) -> tuple[int, int, str]:
    """Return (crop_w, crop_h, axis) for the largest tw:th window that fits."""
    target = tw / th
    if w / h > target:           # source is wider -> crop width, slide on x
        crop_h = h
        crop_w = even(h * target)
        return min(crop_w, w), crop_h, "x"
    crop_w = w                   # source is taller -> crop height, slide on y
    crop_h = even(w / target)
    return crop_w, min(crop_h, h), "y"


def _smooth(track: np.ndarray, alpha: float) -> np.ndarray:
    """Two-pass EMA (forward then backward), averaged, to glide without lag."""
    fwd = track.copy()
    for i in range(1, len(fwd)):
        fwd[i] = alpha * track[i] + (1 - alpha) * fwd[i - 1]
    bwd = track.copy()
    for i in range(len(bwd) - 2, -1, -1):
        bwd[i] = alpha * track[i] + (1 - alpha) * bwd[i + 1]
    return (fwd + bwd) / 2.0


def _track_centers(cap, n_frames, w, h, axis, crop_w, crop_h, cfg) -> np.ndarray:
    # ponytail: detect on a ~640px-wide frame, not full res - face detection is the
    # per-frame cost and downscaling cuts it several-fold with no visible accuracy loss.
    scale = min(1.0, _DETECT_W / w)
    dw, dh = max(1, round(w * scale)), max(1, round(h * scale))
    detector, kind = _make_detector(dw, dh)
    full = w if axis == "x" else h
    crop = crop_w if axis == "x" else crop_h
    lo, hi = crop / 2.0, full - crop / 2.0
    default = full / 2.0

    raw = np.full(n_frames, np.nan)
    idx = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % cfg.detect_every == 0:
            small = cv2.resize(frame, (dw, dh)) if scale < 1.0 else frame
            center = _largest_center(detector, kind, small)
            if center is not None:
                cx, cy = center[0] / scale, center[1] / scale
                raw[idx] = np.clip(cx if axis == "x" else cy, lo, hi)
        idx += 1

    # forward-fill detections, fall back to centre, then smooth
    last = default
    for i in range(n_frames):
        if np.isnan(raw[i]):
            raw[i] = last
        else:
            last = raw[i]
    return np.clip(_smooth(raw, cfg.smooth_alpha), lo, hi)


def _zoom_track(n_frames: int, fps: float, triggers, cfg: Config) -> np.ndarray:
    """Per-frame zoom factor (1.0 = none, up to 1+zoom_amount). Each trigger makes a
    trapezoid bump (ease in, hold, ease out); triggers within zoom_gap are skipped."""
    z = np.ones(n_frames)
    if not triggers or cfg.zoom_amount <= 0:
        return z
    rise, hold, fall = max(1, int(0.25 * fps)), max(1, int(0.2 * fps)), max(1, int(0.4 * fps))
    last = -1e9
    for t in triggers:
        if t - last < cfg.zoom_gap:
            continue
        last = t
        c = int(round(t * fps))
        for k in range(-rise, hold + fall):
            i = c + k
            if i < 0 or i >= n_frames:
                continue
            if k < 0:
                f = (k + rise) / rise          # ease in
            elif k < hold:
                f = 1.0                         # hold
            else:
                f = max(0.0, 1 - (k - hold) / fall)  # ease out
            z[i] = max(z[i], 1.0 + cfg.zoom_amount * f)
    return z


def reframe(clip_path: str, dst: str, cfg: Config, ass_path: str | None = None,
            zoom_at: list[float] | None = None,
            out_w: int | None = None, out_h: int | None = None) -> str:
    """Crop clip_path to vertical, following the speaker, audio preserved.

    If ass_path is given, the captions are burned in this same encode pass instead of
    a separate ffmpeg round trip - one decode+encode per clip instead of two.
    zoom_at is a list of timestamps (seconds) to punch-in on.
    out_w/out_h override the output size (defaults to cfg.target_w/h); used for the
    top region of a split layout.
    """
    ow = out_w or cfg.target_w
    oh = out_h or cfg.target_h
    cap = cv2.VideoCapture(clip_path)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    n_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if not cap.isOpened() or min(w, h, n_frames) <= 0:
        cap.release()
        raise RuntimeError("Video tidak dapat dibaca untuk reframe.")

    crop_w, crop_h, axis = _crop_plan(w, h, ow, oh)
    centers = _track_centers(cap, n_frames, w, h, axis, crop_w, crop_h, cfg)
    zoom = _zoom_track(n_frames, fps, zoom_at if cfg.punch_zoom else None, cfg)

    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-y",
           "-f", "rawvideo", "-pixel_format", "bgr24",
           "-video_size", f"{ow}x{oh}", "-framerate", f"{fps:.4f}",
           "-i", "-", "-i", clip_path,
           "-map", "0:v:0", "-map", "1:a:0?"]
    if ass_path:
        cmd += ["-vf", ass_filter(ass_path, cfg)]
    codec = cfg.video_codec
    cmd += ["-c:v", codec, *encoder_args(codec), "-pix_fmt", "yuv420p", "-c:a", "aac",
            *(final_audio_args(cfg, clip_path) if ass_path else []), "-shortest", "-movflags", "+faststart", dst]
    log = open(str(dst) + ".ffmpeg.log", "wb")
    ff = subprocess.Popen(
        cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=log,
    )

    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
    for i in range(n_frames):
        ok, frame = cap.read()
        if not ok:
            break
        c = centers[i] if i < len(centers) else centers[-1]
        zf = zoom[i] if i < len(zoom) else 1.0
        zw = max(2, min(w, int(round(crop_w / zf))))   # zoom in = take a smaller window
        zh = max(2, min(h, int(round(crop_h / zf))))
        if axis == "x":
            x0 = int(round(c - zw / 2.0)); y0 = (h - zh) // 2
        else:
            y0 = int(round(c - zh / 2.0)); x0 = (w - zw) // 2
        x0 = max(0, min(x0, w - zw)); y0 = max(0, min(y0, h - zh))
        window = frame[y0:y0 + zh, x0:x0 + zw]
        out = cv2.resize(window, (ow, oh), interpolation=cv2.INTER_AREA)
        try:
            ff.stdin.write(out.tobytes())
        except BrokenPipeError:
            break

    cap.release()
    try:
        ff.stdin.close()
    except BrokenPipeError:
        pass
    code = ff.wait()
    log.close()
    if code:
        detail = Path(str(dst) + ".ffmpeg.log").read_text(errors="replace")[-2000:]
        raise RuntimeError("FFmpeg gagal merender. " + detail)
    return dst


def caption_anchors(path, cfg):
    """Choose empty left/right space on landscape shots; fall back to subtitles below."""
    if cfg.target_w <= cfg.target_h or cfg.caption_position != "auto":
        return []
    cap = cv2.VideoCapture(path)
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps, n = cap.get(cv2.CAP_PROP_FPS) or 30, int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if not cap.isOpened() or min(w, h, n) <= 0:
        cap.release()
        return []
    scale = min(1., 640 / w)
    dw, dh = round(w * scale), round(h * scale)
    detector, kind = _make_detector(dw, dh)
    # Side panels are only used when source/output aspects match; crop transforms
    # otherwise change the empty space, so bottom is the honest safe fallback.
    if abs(w / h - cfg.target_w / cfg.target_h) > .08:
        cap.release()
        return []
    anchors = []
    step = max(1, int(fps * 1.5))
    for frame_id in range(0, n, step):
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_id)
        ok, frame = cap.read()
        if not ok:
            break
        small = cv2.resize(frame, (dw, dh))
        if kind == "yunet":
            _, found = detector.detect(small)
            boxes = [] if found is None else [f[:4] for f in found]
        else:
            boxes = detector.detectMultiScale(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY), 1.1, 5)
        choices = []
        for pos, left, right in (("left", .045, .465), ("right", .535, .955)):
            conflict = 0.
            for fx, fy, fw, fh in boxes:
                fx, fy, fw, fh = fx / dw, fy / dh, fw / dw, fh / dh
                # Include a margin around the face, not just the detector box.
                ix = max(0., min(right, fx + fw + .05) - max(left, fx - .05))
                iy = max(0., min(.71, fy + fh + .08) - max(.25, fy - .05))
                conflict += ix * iy
            choices.append((conflict, pos))
        best = min(choices)
        pos = best[1] if len(boxes) and best[0] < .004 else "bottom"
        anchors.append({"time": frame_id / fps, "position": pos})
    cap.release()
    return anchors
