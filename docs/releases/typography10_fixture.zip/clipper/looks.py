"""Complete, versioned looks. Motion can be changed independently after selection."""
VISUAL_FIELDS = {'caption_style','motion_intensity','caption_scale','accent_hex','accent_font',
                 'font_main','font_accent','caption_backdrop'}


def look(ident, name, description, motion, main, accent, color, intensity='calm'):
    return {'id':ident, 'name':name, 'description':description,
            'settings':{'caption_style':motion,'font_main':main,'font_accent':accent,
                        'accent_hex':color,'accent_font':True,'caption_scale':1.,
                        'motion_intensity':intensity,'caption_backdrop':True}}


LOOKS = (
    look('editorial32','Editorial bertingkat','Kata penghubung kecil, serif besar untuk ide utama, susunan ringkas dengan gerak halus.','magazine','dm_sans','dm_serif_italic','#F5D98D','balanced'),
    look('shorts','Shorts dinamis','Frasa ringkas, Montserrat + Bebas Neue, penekanan pop untuk video pendek.','impact','montserrat','bebas','#FFD43B','dynamic'),
    look('studio','Studio editorial','Sans bersih + huruf padat, gerak mengikuti penekanan isi.','narrative','dm_sans','bebas','#EFCB75'),
    look('elegan','Editorial elegan','Sans yang rapi + serif miring untuk penekanan.','narrative','dm_sans','dm_serif_italic','#F6D582'),
    look('tegas','Angka tegas','Huruf padat untuk angka dan istilah penting.','impact','dm_sans','bebas','#FFC857','balanced'),
    look('kelas','Ruang belajar','Susunan tenang, jelas untuk edukasi dan materi.','slide','dm_sans','montserrat','#8BDBC2'),
    look('fokus','Fokus lembut','Serif dengan masuk blur yang singkat.','blur','dm_sans','dm_serif','#E9D7BA'),
    look('energi','Pop editorial','Montserrat + aksen serif dengan pop terukur.','pop','montserrat','dm_serif_italic','#DCC8FF','balanced'),
)
