"""One isolated heavy stage per process. Publish only against matching inputs."""
import argparse
import copy
import sys
import traceback
import threading
from contextlib import contextmanager
from dataclasses import asdict, replace
from pathlib import Path
from .studio_service import StudioService, identifier, CONFIG_FIELDS
from .config import Config
from .project_store import Conflict,JobLeaseLost
from .storage import read_json, write_json
from .contracts import fingerprint
from .dependency_cache import content_id, render_key, asset_id, fresh_scope


class StaleJob(ValueError):pass


def claimed_job(service,job):
    """Synchronous QA/CLI callers use the same atomic claim as the supervisor."""
    current=service.queue.get(job['id'])
    if current['status']=='queued':
        current=service.queue.claim(job['id'])
        if current is None:raise StaleJob('Tugas lain memiliki antrean atau urutan telah berubah.')
    if current['status']!='running':raise StaleJob('Tugas tidak sedang berjalan; hasil tidak dipublikasikan.')
    return current


def save_analysis_take(service,pid,media,transcript,cfg):
    """Keep immutable ASR evidence separate from glossary-dependent display text."""
    from .transcript_correction import VERSION
    transcript=copy.deepcopy(transcript)
    raw=copy.deepcopy(transcript.get('raw_words',transcript['words']))
    for i,word in enumerate(raw):word.setdefault('word_id',i)
    raw_take='asr-raw-'+fingerprint([pid,media['source_id'],media['payload']['audio_stream_id'],
        raw,transcript.get('language'),transcript.get('duration')])[:32]
    evidence={**transcript,'words':raw,'raw_words':raw,'heard_words':raw}
    evidence.pop('correction_report',None);evidence.pop('asr_corrections',None)
    try:service.store.transcript(raw_take)
    except KeyError:service.store.save_transcript(pid,evidence,raw_take)
    processing={key:getattr(cfg,key) for key in ('glossary','approved_aliases','audience','transcript_correction')}
    transcript.update(raw_words=raw,raw_take_id=raw_take,
        display_processing={'version':VERSION,'settings':processing})
    take='display-'+fingerprint([raw_take,VERSION,processing,transcript['words'],
        transcript.get('heard_words'),transcript.get('segments')])[:32]
    try:service.store.transcript(take)
    except KeyError:service.store.save_transcript(pid,transcript,take)
    return take


def execute(service,job):
    job=claimed_job(service,job)
    # Direct QA/CLI execution has no supervisor. Only that original queue owner
    # renews its lease; a spawned worker cannot keep an orphaned parent alive.
    @contextmanager
    def synchronous_lease():
        stop=threading.Event();thread=None
        if job['owner']==service.queue.owner:
            def heartbeat():
                while not stop.wait(min(5,service.queue.lease_seconds/3)):
                    if not service.queue.heartbeat(job):return
            thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
        try:yield
        finally:
            stop.set()
            if thread:thread.join(1)
    try:
        with synchronous_lease():return _execute(service,job)
    except BaseException as exc:
        if job['owner']==service.queue.owner:
            active=service.queue.get(job['id'])
            status='canceled' if active['status']=='cancel_requested' else 'stale' if isinstance(exc,StaleJob) else 'failed'
            if active['status'] in ('running','cancel_requested'):
                try:service.queue.update_owned(job,status=status,error=str(exc)[-4000:],message='Eksekusi sinkron berakhir; hasil sebelumnya tetap tersedia.')
                except JobLeaseLost:pass
        raise


def _execute(service,job):
    if job['kind'] in ('gallery_m5','cover_m5'):
        from .finishing5_jobs import execute
        return execute(service,job)
    if job['kind']=='export_project':
        from .batch7 import export_project
        return export_project(service,job)
    if job['kind']=='evaluation':return evaluation_job(service,job)
    if job['kind']=='selection_m3':
        from .selection_service import execute
        return execute(service,job)
    if job['kind']=='camera_m4':
        from .camera4_service import execute
        return execute(service,job)
    from . import media_context, evidence, transcript_correction, story, analysis_adapter, editorial
    pid=job['project_id'];target=job['target'];cid=target.get('clip_id');vid=target.get('variant_id','portrait');kind=job['kind']
    doc=copy.deepcopy(job['request'].get('snapshot') or service.store.get(pid));dependency=job['request']['dependency'];cfg=service.config(doc,cid,vid)
    work=Path(cfg.work_dir);work.mkdir(parents=True,exist_ok=True)
    def progress(value,message):service.queue.update_owned(job,progress=max(0,min(100,int(value))),message=message)
    def check(current=None):
        # One fresh snapshot per validation phase. Never reuse a fresh hash
        # across the expensive stage or the subsequent publication check.
        with fresh_scope():return validate(current)
    def validate(current=None):
        current=current or service.store.get(pid)
        active=service.queue.get(job['id'])
        if active['status'] in ('cancel_requested','canceled') or active['owner']!=job.get('owner') or active.get('lease_token')!=job.get('lease_token'):
            raise StaleJob('Proses sudah dibatalkan atau lease berubah')
        validated=doc if job['request'].get('draft_id') else current
        if dependency!=service.dependency(validated,cid,vid,fresh=True,kind=kind):raise StaleJob('Masukan berubah ketika proses berjalan. Hasil lama dipertahankan; jalankan ulang revisi aktif.')
        if job['request'].get('draft_id') and current['source']['source_id']!=doc['source']['source_id']:
            raise StaleJob('Sumber aktif berubah; snapshot draf tidak diterbitkan')
        if kind!='analyze' and current['source'].get('requires_analysis'):raise StaleJob('Sesi lama belum mempunyai identitas sumber yang terverifikasi. Analisis ulang sebelum menerapkan koreksi atau render.')
        if kind!='analyze' and content_id(current['source']['path'],fresh=True)!=current['source']['source_id']:
            raise StaleJob('Isi sumber berubah. Analisis ulang sebelum memakai transkrip atau hasil lama.')
        return current
    check()
    progress(1,'Memeriksa revisi dan berkas sumber')
    # ASR, local LLM and OCR/vision have no simultaneous GPU ownership.
    editorial.release(cfg)
    prior_media=doc['source'].get('media_context',{}).get('payload',{})
    expected_track=cfg.audio_stream_index if cfg.audio_stream_index>=0 else doc['source']['info']['audio_tracks'][0]['index']
    if kind not in ('analyze','source_evidence','waveform') and prior_media and prior_media.get('selected_audio_index')!=expected_track:
        raise StaleJob('Track suara berubah; analisis sumber kembali sebelum merender subtitle.')
    media=media_context.prepare(doc['source']['path'],cfg,progress)
    cfg=replace(cfg,source_content_id=media['source_id'],audio_stream_id=media['payload']['audio_stream_id'])
    source=media['payload']['working_path'];result={};updates={};variant_updates={}
    if kind=='analyze':
        from . import pipeline
        transcript,candidates=pipeline.analyze(source,cfg,progress)
        take=save_analysis_take(service,pid,media,transcript,cfg)
        updates.update(transcript_id=take,discovery=read_json(work/'selection-report.json',{}))
        result={'candidates':len(candidates),'transcript_id':take,'timings':transcript.get('timings'),
                'runtime_receipt':transcript.get('runtime_receipt',{}),'audio_stream_id':media['payload']['audio_stream_id']}
    elif kind=='source_evidence':
        report=evidence.scan(source,cfg,media['payload']['duration'],progress,input_fingerprint=media['input_fingerprint'])
        result={'evidence':report};updates['evidence_summary']={k:v for k,v in report.items() if k not in ('frames','audio')}
    elif kind=='proxy':
        result=media_context.proxy(doc['source']['path'],cfg,progress);updates['m2_proxy']=result
    elif kind=='diarization':
        from .speech_m2 import run_isolated
        result=run_isolated('diarization',source,cfg);updates['diarization']={**result,'transcript_id':doc['transcript_id']}
    elif kind=='translation':
        data={**job['request']['options'],'expected_revision':doc['revision']}
        result=service.transcripts.translation_review(pid,data,owned_worker=True)
    elif kind=='waveform':
        from .audio_quality import waveform
        result=waveform(source,media['payload']['duration']);updates['waveform']=result
    else:
        transcript=service.transcript(doc,cid,vid);words=transcript['words']
        if kind=='correction':
            transcript['ocr_suggestions']=evidence.suggestions(words,evidence.load(cfg))
            refined=transcript_correction.refine(transcript,cfg)
            take='corrected-'+fingerprint([pid,doc['transcript_id'],refined['words'],doc.get('aliases')])[:32]
            try:service.store.transcript(take)
            except KeyError:service.store.save_transcript(pid,refined,take)
            updates['transcript_id']=take;updates['correction_report']=refined['correction_report'];result={'review_items':len(refined['correction_report']['review'])}
        elif kind=='discovery':
            candidates=story.select(transcript,cfg,progress,existing=list(doc['clips'].values()))
            updates['discovery']=read_json(work/'selection-report.json',{});result={'candidates':len(candidates)}
        elif kind=='asr_recheck':
            from . import speech_jobs
            original=service.store.transcript(doc['transcript_id']);heard=copy.deepcopy(original.get('heard_words',original.get('raw_words',original['words'])))
            from .transcript_service import all_patches
            protected={i for patch in all_patches(doc) if patch['transcript_id']==doc['transcript_id'] for i in patch['origin_word_ids']}
            for word in heard:
                if set(transcript_correction.source_ids([word]))&protected:word['manually_edited']=True
            payload={**original,'words':heard};options=copy.deepcopy(job['request'].get('options',{}))
            if cid and not options.get('origin_word_ids'):
                selected=[w for w in heard if w['end']>doc['clips'][cid]['start'] and w['start']<doc['clips'][cid]['end'] and transcript_correction.suspect_reason(w)]
                if not selected:result={'checked':0,'accepted':0,'note':'Tidak ada kata berkeyakinan rendah dalam klip ini.'}
                else:options['origin_word_ids']=transcript_correction.source_ids(selected)[:80]
            if not result:
                progress(12,'Mendengarkan ulang rentang terarah dengan model ASR lokal')
                response=speech_jobs.run(kind,source,payload,cfg,options);result=response['report']
                if response['changes']:
                    for word in response['words']:word.pop('manually_edited',None)
                    refined=speech_jobs.rechecked_transcript(original,response,cfg)
                    take='rechecked-'+fingerprint([pid,doc['transcript_id'],refined['heard_words']])[:32]
                    try:service.store.transcript(take)
                    except KeyError:service.store.save_transcript(pid,refined,take)
                    updates['transcript_id']=take;updates['correction_report']=refined['correction_report']
            updates['speech_reports']={**doc.get('speech_reports',{}),'asr_recheck':result}
        elif kind=='alignment':
            from . import speech_jobs
            payload=transcript;options=copy.deepcopy(job['request'].get('options',{}))
            if cid and not options.get('origin_word_ids'):
                selected=[w for w in words if w['end']>doc['clips'][cid]['start'] and w['start']<doc['clips'][cid]['end']
                    and (w.get('correction') or w.get('manually_edited') or len(w['word'].split())>1) and not w.get('aligned_words')]
                options['origin_word_ids']=transcript_correction.source_ids(selected)[:80]
                if not selected:result={'aligned':0,'attempted':0,'status':'skipped','errors':[],'device':'cpu','note':'Tidak ada frasa dalam klip ini yang memerlukan alignment.'}
            progress(12,'Menyelaraskan frasa yang dikoreksi dengan model CTC lokal pada CPU')
            response=speech_jobs.run(kind,source,payload,cfg,options) if not result else {'report':result,'patches':[]};result=response['report']
            alignment_patches=response['patches']
            updates['speech_reports']={**doc.get('speech_reports',{}),'alignment':result}
        elif kind=='boundary_review':
            reviewed=story.review_candidate(doc['clips'][cid],transcript,cfg,refresh=True)
            result={'review':reviewed}
        elif kind in ('visual_review','style_review'):
            from . import composition,editplan,ffmpeg_util,visual4
            from .studio_exchange import render_words
            clip={k:v for k,v in doc['clips'][cid].items() if k!='variants'};variant=service.variant(doc,cid,vid)
            if variant.get('timeline'):clip['manual_keep_spans']=variant['timeline']['keep_spans']
            display=render_words(transcript,doc,clip,cfg)
            progress(10,'Memeriksa wajah, materi dan ruang teks sepanjang klip')
            from .pipeline import source_plan
            display,plan=source_plan(source,display,clip,cfg,ffmpeg_util.probe(source),context_words=transcript['words'])
            if kind=='style_review':
                from .typography import make_plan
                from .placement import caption_anchors
                from .subtitle_edit import clean
                from .style5 import readability,annotate_prosody
                from . import render
                cleaned,_,_=clean(plan['words'],cfg.caption_cleanup,cfg.caption_punctuation,cfg)
                voice=render.voice_stem(source,plan,cfg,work/'style-review-audio')
                cleaned=annotate_prosody(cleaned,voice)
                plan['display_words']=cleaned
                from .finishing5_service import caption_config
                captions=make_plan(cleaned,caption_config(plan,cfg),clip.get('keywords',[]),anchors=caption_anchors(plan,cfg))
                result=readability(captions,cfg)
                result['selected_alignment']=plan.get('selected_alignment')
                for phrase in result['phrases']:
                    span=next((s for s in plan['spans'] if s['start']<=phrase['start']<s['end']),None)
                    if span:phrase['source_start']=span['source_start']+phrase['start']-span['start']
                variant_updates.update(style_report=result,style_dependency=dependency)
            else:
                result=visual4.report(plan,source,cfg)
                variant_updates.update(visual_report=result,visual_dependency=dependency)
        elif kind in ('asset_proposals','asset_visual_review'):
            from . import illustrations
            clip={k:v for k,v in doc['clips'][cid].items() if k!='variants'}
            if cfg.broll_mode=='off':cfg=replace(cfg,broll_mode='local')
            recipe=illustrations.prepare(words,clip,cfg,progress,input_fingerprint=dependency)
            proposals=analysis_adapter.asset_proposal_set(recipe,source_id=media['source_id'],input_fingerprint=dependency,cfg=cfg)
            variant_updates.update(recipe=recipe,asset_proposals=proposals)
            if service.variant(doc,cid,vid).get('settings',{}).get('broll_mode',doc['settings'].get('broll_mode','off'))=='off':
                variant_updates['settings']={**service.variant(doc,cid,vid).get('settings',{}),'broll_mode':'local'}
            result={'proposals':len(recipe.get('scenes',[])),'notes':recipe.get('notes',[])}
        elif kind in ('preview','render'):
            from . import pipeline
            clip={k:v for k,v in doc['clips'][cid].items() if k!='variants'};variant=service.variant(doc,cid,vid)
            from .studio_exchange import render_words,records
            words=render_words(transcript,doc,clip,cfg)
            if transcript.get('m2_translation') and transcript['m2_translation']['display_mode']=='bilingual':clip['_m2_translation']=transcript['m2_translation']
            clip['revision']=variant.get('timeline_revision',0)+doc['transcript_revision']
            clip['_broll_recipe']=variant.get('recipe') or {'scenes':[],'notes':['Siapkan ilustrasi untuk memilih aset.']}
            if variant.get('timeline'):clip['manual_keep_spans']=variant['timeline']['keep_spans']
            if kind=='preview':
                quality=job['request'].get('options',{}).get('quality','draft');edge=1280 if quality=='detail' else 640
                scale=edge/max(cfg.target_w,cfg.target_h)
                folder=work/'cache'/'previews'/(dependency[:24]+'-'+quality)
                cfg=replace(cfg,target_w=round(cfg.target_w*scale/2)*2,target_h=round(cfg.target_h*scale/2)*2,
                    work_dir=str(folder),out_dir=str(folder/'output'),job_id='',preview_seconds=0,
                    audio_cache_dir=cfg.audio_cache_dir or str(work),visual_cache_dir=cfg.visual_cache_dir or str(work/'visual4'))
                folder.mkdir(parents=True,exist_ok=True)
                if (work/'source-evidence.json').is_file():write_json(folder/'source-evidence.json',read_json(work/'source-evidence.json'))
            key=fingerprint([dependency,'preview',cfg.target_w,cfg.target_h,quality]) if kind=='preview' else dependency
            # A full-content manifest is checked on every reuse, including the output itself.
            cached=read_json(Path(cfg.work_dir)/'render-cache'/f'{key}.json',{})
            path=Path(cached.get('absolute_file',''))
            from .artifact_store import verify,studio_set
            reused=False
            if (not job['request'].get('options',{}).get('force') and path.is_file()
                    and cached.get('output_content_id')==content_id(path,fresh=True) and verify(cached)):
                result=copy.deepcopy(cached);reused=True
            else:
                name=f'{cid}-{vid}-{key[:12]}'
                from .camera4_service import renderable as camera_renderable
                camera=camera_renderable(service,doc,cid,vid)
                if camera:clip['_m4_camera']=camera
                from .editor_media import prepare
                render_source,render_display,render_clip,render_cfg,edit_receipt=prepare(service,doc,cid,vid,source,words,clip,cfg,progress)
                result=pipeline.render_clip(render_source,render_display,render_clip,name,render_cfg,progress,
                    context_words=render_display if edit_receipt else transcript['words'])
                if edit_receipt:result['editor_receipt']=edit_receipt
                path=Path(cfg.out_dir)/result['file']
                result.update(absolute_file=str(path.resolve()),output_content_id=content_id(path,fresh=True),fingerprint=key,dependency=dependency,
                    variant_id=vid,input_revision=doc['revision'],kind=kind,quality=job['request'].get('options',{}).get('quality','draft') if kind=='preview' else 'final')
            plan=read_json(result['plan_path'],{})
            if result.get('editor_receipt') and plan.get('editor'):
                result['editor_receipt']['proxy_path']=plan['source']['path']
            result.update(fingerprint=key,dependency=dependency,variant_id=vid,kind=kind,
                          quality=job['request'].get('options',{}).get('quality','draft') if kind=='preview' else 'final')
            if job['request'].get('render_summary'):
                result['render_summary']=copy.deepcopy(job['request']['render_summary'])
            if job['request'].get('draft_id'):
                result.update(draft_id=job['request']['draft_id'],snapshot_digest=job['request']['snapshot_digest'],is_draft=True)
            result,plan,exchange=studio_set(result,plan,doc,cid,vid,cfg,media,dependency,before_seal=check,reused=reused)
            from urllib.parse import unquote
            for field in ('ass_url','srt_url','credits_url'):
                result[field]=service.register_file(pid,Path(cfg.out_dir)/unquote(result[field].removeprefix('/clips/')))
            result['url']=service.register_file(pid,result['absolute_file'])
            from .runtime.state import write
            write(Path(cfg.work_dir)/'render-cache'/f'{key}.json',result)
            from . import visual4
            if plan.get('m4'):
                visual_report={'summary':{**plan.get('visual_summary',{}),'key':plan['m4']['analysis_id'],'scope':'M4 approved composition; no duplicate legacy inference'},'shots':[],'m4':plan['m4']}
            elif not cfg.visual_enabled:
                visual_report={'summary':{'status':'disabled','scope':'legacy visual report disabled by configuration'},'shots':[]}
            else:visual_report=visual4.report(plan,source,cfg)
            variant_updates.update({('preview' if kind=='preview' else 'result'):result,'schedule':plan.get('broll_schedule',[]),'schedule_dependency':dependency,
                'timeline_summary':{k:plan.get(k) for k in ('spans','duration','fps','width','height','warnings','audio_quality')},
                'shot_summary':[{k:s.get(k) for k in ('start','end','source_start','source_end','mode','has_material','composition_reason')} for s in plan.get('shots',[])],
                'visual_report':visual_report,'visual_dependency':dependency,
                'style_report':plan.get('style_report',{}),'style_dependency':dependency})
            result['evaluation_context']={'source_id':media['source_id'],'audio_stream_id':media['payload']['audio_stream_id'],
                'transcript_id':doc['transcript_id'],'word_fingerprint':fingerprint(words),
                'source_spans':[[s['source_start'],s['source_end']] for s in plan['spans']],
                'variant_id':vid,'width':cfg.target_w,'height':cfg.target_h,'fps':plan['fps'],
                'duration':plan['duration'],'quality':result.get('quality'),
                'audio_mix_content_id':content_id(plan['audio']['mix'],fresh=True)}
            from .workflow6 import BRAND_FIELDS
            result['evaluation_settings']={k:v for k,v in asdict(cfg).items() if k in BRAND_FIELDS}
        elif kind=='export':
            from . import projects
            final=service.variant(doc,cid,vid).get('result')
            if not final or final.get('dependency')!=dependency:raise ValueError('Render final revisi aktif dahulu sebelum ekspor editor')
            if not Path(final['absolute_file']).is_file() or content_id(final['absolute_file'],fresh=True)!=final['output_content_id']:raise ValueError('Berkas final berubah atau hilang; render ulang')
            if final.get('plan_content_id') and content_id(final['plan_path'],fresh=True)!=final['plan_content_id']:raise ValueError('Rencana final berubah; render ulang')
            result=projects.export_bundle([final],cfg,progress,mode=job['request'].get('options',{}).get('mode','hybrid'))
            result['url']=service.register_file(pid,result['zip']);result['clip_id']=cid;result['variant_id']=vid
            result.update(dependency=dependency,input_revision=doc['revision'])
            result['package_content_id']=content_id(result['zip'],fresh=True)
            result['reference']={k:final.get(k) for k in ('width','height','length','output_content_id','input_revision')}
    check()
    if job['request'].get('draft_id'):
        service.store.publish_editor_draft(pid,{**job,'clip_id':cid,'variant_id':vid},result)
        editorial.release(cfg)
        return result
    def publish(current):
        check(current)
        old_take=current.get('transcript_id');old_source=current['source']['source_id']
        old_audio=current['source'].get('media_context',{}).get('payload',{}).get('audio_stream_id')
        current['source'].update(source_id=media['source_id'],media_context=media,info={k:v for k,v in media['payload'].items() if k!='working_content_id'})
        current.update(updates)
        if kind=='proxy':current['source']['edit_proxy']=result;current.pop('m2_proxy',None)
        if kind=='translation':
            result['approval_revision']=publish_revision
            current.setdefault('translation_proposals',[]).append(copy.deepcopy(result))
        if kind in ('analyze','discovery'):
            if old_take and (current['source'].get('requires_analysis') or old_source!=media['source_id'] or old_audio and old_audio!=media['payload']['audio_stream_id']):
                current.setdefault('archived_clips',[]).append({'source_id':old_source,'transcript_id':old_take,'clips':current['clips']})
                current['clips']={}
            service.add_candidates(current,candidates)
            current['candidate_set']=analysis_adapter.candidate_set(list(current['clips'].values()),current.get('discovery',{}),
                source_id=media['source_id'],input_fingerprint=dependency)
        if kind in ('analyze','correction','asr_recheck') and old_take!=current['transcript_id']:
            current['transcript_revision']+=1
            compatible=kind in ('correction','asr_recheck')
            if kind=='analyze' and old_take and old_source==media['source_id'] and old_audio==media['payload']['audio_stream_id']:
                before=service.store.transcript(old_take)
                after=service.store.transcript(current['transcript_id'])
                compatible=before.get('raw_words',before['words'])==after.get('raw_words',after['words'])
            if kind=='analyze':
                current['transcript_lineage']={'from':old_take,'to':current['transcript_id'],
                    'manual_patches_preserved':compatible,'basis':'identical_source_audio_and_raw_words' if compatible else 'new_asr_evidence'}
            if compatible:
                from .transcript_service import all_patches
                for patch in all_patches(current):
                    if patch['transcript_id']==old_take:patch['transcript_id']=current['transcript_id']
                for patch in current.get('manual_speakers',{}).values():
                    if patch['transcript_id']==old_take:patch['transcript_id']=current['transcript_id']
                if current.get('diarization',{}).get('transcript_id')==old_take:current['diarization']['transcript_id']=current['transcript_id']
                for group in [current.get('shared_corrections',{}),*current.get('clip_corrections',{}).values()]:
                    for patch in group.values():
                        if patch['transcript_id']==old_take:patch['transcript_id']=current['transcript_id']
                timing=current.get('alignment_overrides',{})
                for group in [timing.get('shared',{}),*timing.get('clips',{}).values()]:
                    for patch in group.values():
                        if patch['transcript_id']==old_take:patch['transcript_id']=current['transcript_id']
        if kind in ('analyze','discovery') and current.get('discovery'):
            current['discovery']['transcript_id']=current['transcript_id']
            current['discovery']['transcript_revision']=current['transcript_revision']
        if kind=='alignment':
            patches=current.setdefault('alignment_overrides',{})
            group=patches.setdefault('clips',{}).setdefault(cid,{}) if cid else patches.setdefault('shared',{})
            for patch in alignment_patches:
                patch['transcript_id']=current['transcript_id'];patch['provenance'].update(source_id=media['source_id'],audio_stream_id=media['payload']['audio_stream_id'])
                from .stage3 import store_alignment
                store_alignment(group,patch)
            if alignment_patches:current['transcript_revision']+=1
        if kind=='analyze':current['source']['requires_analysis']=False
        if kind in ('analyze','correction','asr_recheck','alignment','diarization'):
            from .selection_service import invalidate
            invalidate(service,current)
        if cid:
            service.variant(current,cid,vid).update(variant_updates)
            if kind=='boundary_review':
                keep=current['clips'][cid]['variants'];current['clips'][cid].update(reviewed);current['clips'][cid]['variants']=keep
        if kind=='export':current.setdefault('exports',[]).append(result)
    for attempt in range(5):
        current=check();publish_revision=current['revision']+1
        try:
            saved=service.store.mutate(pid,current['revision'],job['id']+'-publish',{'job_id':job['id'],'dependency':dependency},publish,'Selesai: '+kind,
                job_guard={**job,'clip_id':cid,'variant_id':vid},job_result=result);break
        except Conflict:
            if attempt==4:raise
    editorial.release(cfg)
    message='Selesai dan tersimpan pada revisi '+str(saved['revision'])
    if kind=='alignment':
        if result.get('errors'):
            message=f"Alignment perlu diperiksa: {result.get('aligned',0)} frasa berhasil, {len(result['errors'])} ditolak. Buka Alignment terakhir."
        elif not result.get('aligned'):
            message='Tidak ada koreksi baru yang perlu diselaraskan. Model belum menjalankan pengukuran.'
        else:message=f"Alignment berhasil: {result['aligned']} frasa diselaraskan pada CPU; tersimpan pada revisi {saved['revision']}."
    service.queue.update_owned(job,message=message)
    if kind=='analyze' and cfg.m3_auto_selection and cfg.processing_mode!='full':
        profile='finance' if cfg.audience=='finance' else 'education' if cfg.source_kind=='board' else 'screen' if cfg.source_kind in ('screen','chart','graphic') else 'podcast' if cfg.source_kind=='podcast' else 'general'
        # ASR has already been saved. A concurrent unrelated style edit must
        # not turn that successful job into a failure while scheduling M3.
        service.enqueue(pid,'selection_m3',options={'profile':profile})
    return result


def evaluation_job(service,job):
    """CPU comparison path avoids loading any ASR/CV/model or canonical decoder."""
    job=claimed_job(service,job)
    from .evaluation6 import evaluate_artifacts
    pid=job['project_id'];cid=job['target']['clip_id'];vid=job['target']['variant_id'];dependency=job['request']['dependency']
    def check():
        doc=service.store.get(pid)
        if service.queue.get(job['id'])['status'] in ('cancel_requested','canceled'):raise StaleJob('Evaluasi dibatalkan.')
        if dependency!=service.dependency(doc,cid,vid,fresh=True):raise StaleJob('Revisi masukan berubah; jalankan evaluasi ulang.')
        if content_id(doc['source']['path'],fresh=True)!=doc['source']['source_id']:raise StaleJob('Sumber berubah.')
        return doc
    def progress(value,message):service.queue.update_owned(job,progress=int(value),message=message)
    check();value=evaluate_artifacts(service,pid,job['request'].get('options',{}),progress);check()
    result=service.workspace.append('evaluations6',pid,value)
    for attempt in range(5):
        current=check()
        try:
            service.store.mutate(pid,current['revision'],job['id']+'-publish',{'evaluation_id':result['id']},
                lambda d: service.variant(d,cid,vid).update(evaluation_report=result),'Evaluasi dua hasil tersimpan',
                job_guard={**job,'clip_id':cid,'variant_id':vid},job_result=result)
            break
        except Conflict:
            if attempt==4:raise
    service.queue.update_owned(job,message='Perbedaan piksel diukur; penilaian manusia dapat diisi.')
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--db',required=True);parser.add_argument('--job',required=True);args=parser.parse_args()
    from .project_store import ProjectStore
    from .job_queue import JobQueue
    store=ProjectStore(args.db);queue=JobQueue(store,Path(args.db).parent,autostart=False,recover=False);job=queue.get(args.job)
    doc=store.get(job['project_id']);settings=doc.get('settings',{})
    cfg=Config(**{k:v for k,v in settings.items() if k in CONFIG_FIELDS})
    cfg=replace(cfg,work_dir=str(Path(args.db).resolve().parent))
    service=StudioService(Path(__file__).resolve().parent.parent,cfg,db_path=args.db,autostart=False,recover=False)
    from .runtime.gpu import GPULease
    from .runtime.state import runtime_root
    import os
    os.environ['CLIPPER_RUNTIME_DIR']=str(runtime_root(service.root,service.work))
    try:
        # Close the launch/record-PID window. An orphan launched before its PID
        # was persisted must not begin an expensive stage.
        import time
        deadline=time.monotonic()+2
        while queue.get(job['id']).get('pid') is None and time.monotonic()<deadline:time.sleep(.05)
        if queue.get(job['id']).get('pid')!=os.getpid():raise StaleJob('Worker belum tercatat oleh supervisor; proses dihentikan.')
        with GPULease(runtime_root(service.root,service.work),'proyek '+job['kind']):
            try:execute(service,job)
            finally:
                from .editorial import release
                release(service.config(doc))
    except (StaleJob,JobLeaseLost) as exc:
        active=queue.get(args.job)
        if active.get('owner')==job.get('owner') and active.get('lease_token')==job.get('lease_token'):
            if active['status']=='running':queue.update_owned(job,status='stale',message=str(exc),error=str(exc))
            elif active['status']=='cancel_requested':queue.update_owned(job,message='Worker berakhir; menunggu pengakuan supervisor.',error=str(exc))
    except BaseException as exc:
        traceback.print_exc()
        active=queue.get(args.job)
        if active.get('owner')==job.get('owner') and active.get('lease_token')==job.get('lease_token') and active['status']=='running':
            queue.update_owned(job,status='failed',message='Proses gagal; perubahan dan hasil sebelumnya tetap tersedia.',error=str(exc)[-4000:])
        return 1
    return 0


if __name__=='__main__':sys.exit(main())
