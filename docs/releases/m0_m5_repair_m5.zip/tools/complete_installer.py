"""Offline code overlay with baseline checks, recoverable journal and rollback.

Python standard library only. Project data and model environments are outside
the allowed payload paths. Run from an extracted release, not from payload/.
"""
import argparse
import ast
import hashlib
import json
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import sys
from datetime import datetime
from pathlib import Path, PurePosixPath


ROOT_FILES = {'README.md', 'app.py', 'doctor_pro.py', 'requirements.txt',
              'requirements-pro.txt', 'JALANKAN_PRO.cmd', 'CEK_PRO.cmd', '.gitignore', 'CEK_PEMBENAHAN.cmd'}


def checksum(path, text=False):
    data = path.read_bytes()
    return hashlib.sha256(data.replace(b'\r\n', b'\n') if text else data).hexdigest()


def safe_path(root, name):
    if not isinstance(name, str) or not name or '\\' in name or ':' in name or '\0' in name:
        raise ValueError('Path paket tidak valid: ' + str(name))
    rel = PurePosixPath(name)
    if rel.is_absolute() or '..' in rel.parts or str(rel) != name:
        raise ValueError('Path paket tidak aman: ' + name)
    if rel.parts[0] not in {'clipper', 'static', 'docs', 'tools'} and name not in ROOT_FILES:
        raise ValueError('Payload hanya boleh berisi kode aplikasi: ' + name)
    root = root.resolve()
    path = root.joinpath(*rel.parts)
    current = root
    for part in rel.parts:
        current = current / part
        if current.is_symlink():
            raise ValueError('Symlink tidak diizinkan: ' + name)
    if not path.resolve().is_relative_to(root):
        raise ValueError('Path keluar dari folder: ' + name)
    return path


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    try:
        with temp.open('w', encoding='utf-8', newline='\n') as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def atomic_copy(source, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    temp = dest.with_name(dest.name + '.complete-tmp')
    try:
        with source.open('rb') as src, temp.open('wb') as out:
            shutil.copyfileobj(src, out); out.flush(); os.fsync(out.fileno())
        shutil.copystat(source, temp)
        os.replace(temp, dest)
    finally:
        temp.unlink(missing_ok=True)


def require_stopped(port=8765):
    try:
        connection = socket.create_connection(('127.0.0.1', port), timeout=.3)
    except OSError:
        return
    connection.close()
    raise ValueError(f'Tutup server Clipper pada port {port} dengan Ctrl+C sebelum melanjutkan.')


def python_for(target):
    path = target / '.venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    if not path.is_file():
        raise ValueError('Python .venv mesin lama tidak ditemukan. Pilih folder instalasi yang dipakai menjalankan Clipper.')
    return path


def probe_runtime(target, after=False):
    python = python_for(target)
    code = ('import importlib.util,json,sys; '
            "names=['fastapi','requests','PIL','cv2','multipart','dotenv']; "
            'missing=[name for name in names if importlib.util.find_spec(name) is None]; '
            "assert sys.version_info >= (3,10), 'Python 3.10 atau lebih baru diperlukan'; "
            "assert not missing, 'Modul belum tersedia: '+', '.join(missing); "
            'sys.path.insert(0,sys.argv[1]); '
            'from pathlib import Path; from dotenv import load_dotenv; '
            "load_dotenv(Path(sys.argv[1])/'.env'); "
            "load_dotenv(Path(sys.argv[1])/'.env.pro',override=True); from clipper.config import Config; ")
    if after:
        code += 'import clipper.framing,clipper.batch7,clipper.projects,clipper.pipeline,clipper.visual4,clipper.visual_worker,clipper.stage3,clipper.speech_jobs,clipper.api_studio,clipper.studio_exchange,clipper.style5,clipper.caption_renderer,clipper.explanation5,clipper.asset_rank,clipper.workflow6,clipper.evaluation6,clipper.export6,clipper.metrics6; '
        if (target/'clipper/caption_director.py').is_file():
            code += 'import clipper.caption_director,clipper.text_area,clipper.segmentation; '
        if (target/'clipper/caption_fit.py').is_file():
            code += 'import clipper.caption_fit,clipper.caption_geometry,clipper.selected_alignment,clipper.semantic_rank; '
    if after and (target/'clipper/transcript_tracks.py').is_file():
        code += 'import clipper.transcript_tracks,clipper.transcript_service,clipper.source_imports,clipper.source_assembly,clipper.speech_m2,clipper.translation_m2,clipper.bilingual_m2,clipper.audio_project,clipper.api_ingest; '
    if after and (target/'clipper/artifact_store.py').is_file():
        code += 'import clipper.artifact_store,clipper.caption_readability,clipper.studio_worker; '
    if after and (target/'clipper/selection_contract.py').is_file():
        code += 'import clipper.selection_contract,clipper.selection_index,clipper.selection_signals,clipper.selection_engine,clipper.selection_service,clipper.api_selection; '
    if after and (target/'clipper/finishing5_contract.py').is_file():
        code += 'import clipper.finishing5_contract,clipper.finishing5_assets,clipper.finishing5_plan,clipper.finishing5_render,clipper.finishing5_service,clipper.finishing5_jobs,clipper.api_finishing5; '
    if after and (target/'clipper/camera4_contract.py').is_file():
        code += 'import clipper.camera4_contract,clipper.camera4_observe,clipper.camera4_plan,clipper.camera4_tracking,clipper.camera4_render,clipper.camera4_service,clipper.api_camera4; '
    code += "print(json.dumps({'python':sys.version.split()[0],'core_modules':'available','work_dir':str((Path(sys.argv[1])/Config().work_dir).resolve())}))"
    process = subprocess.run([str(python), '-I', '-c', code, str(target)], cwd=target,
                             capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=45)
    if process.returncode:
        raise ValueError('Pemeriksaan Python gagal: ' + process.stderr[-1500:])
    if not after:
        for command in ('ffmpeg', 'ffprobe'):
            check = subprocess.run([command, '-version'], capture_output=True, timeout=15)
            if check.returncode:
                raise ValueError(command + ' belum bisa dijalankan.')
    return json.loads(process.stdout.strip())


def load_manifest(package):
    data = json.loads((package / 'manifest.json').read_text(encoding='utf-8'))
    if not isinstance(data, dict) or data.get('schema_version') != 1 or data.get('version') not in ('4.0.8','4.0.9','4.0.10','4.0.11','4.0.12','4.0.13','4.0.14','4.0.15','4.0.16'):
        raise ValueError('Manifest bukan paket Pembenahan Lengkap yang didukung.')
    managed = set()
    for key in ('files', 'guards'):
        rows = data.get(key)
        if not isinstance(rows, list) or not rows:
            raise ValueError('Daftar ' + key + ' tidak lengkap.')
        seen = set()
        for row in rows:
            if not isinstance(row, dict) or not isinstance(row.get('path'), str):
                raise ValueError('Entri ' + key + ' tidak valid.')
            safe_path(package, row['path'])
            name = row['path'].casefold()
            if name in seen or name in managed:
                raise ValueError('Path ganda dalam manifest: ' + row['path'])
            seen.add(name)
            managed.add(name)
            if key == 'files' and (not isinstance(row.get('sha256'), str) or not re.fullmatch(r'[0-9a-f]{64}', row['sha256'])):
                raise ValueError('Checksum payload tidak valid.')
            allowed = row.get('allowed_text_sha256', [])
            if not isinstance(allowed, list) or not allowed or any(not isinstance(h, str) or not re.fullmatch(r'[0-9a-f]{64}', h) for h in allowed):
                raise ValueError('Checksum dasar tidak valid.')
            if row.get('baseline_checksum', 'sha256-lf') not in ('sha256-lf', 'sha256'):
                raise ValueError('Mode checksum dasar tidak valid.')
    preserved = data.get('preserved_local_files', [])
    if not isinstance(preserved, list):
        raise ValueError('Daftar file lokal yang dipertahankan tidak valid.')
    for name in preserved:
        safe_path(package, name)
        if name.casefold() in managed:
            raise ValueError('File lokal yang dipertahankan tercantum dalam payload/guard: ' + name)
    return data


def preflight(target, package, runtime=True, stopped=True):
    target, package = target.resolve(), package.resolve()
    if target == package or target.is_relative_to(package / 'payload'):
        raise ValueError('Pilih folder mesin lama, bukan folder paket upgrade atau payload.')
    if not (target / 'app.py').is_file() or not (target / 'clipper').is_dir():
        raise ValueError('Folder mesin harus berisi app.py dan folder clipper.')
    manifest = load_manifest(package)
    for row in manifest['files']:
        source = safe_path(package / 'payload', row['path'])
        if not source.is_file() or checksum(source) != row['sha256']:
            raise ValueError('Paket rusak atau tidak lengkap: ' + row['path'])
        if source.suffix == '.py':
            ast.parse(source.read_text(encoding='utf-8-sig'), filename=row['path'])
    conflicts = []
    for row in manifest['guards']:
        dest = safe_path(target, row['path'])
        if not dest.is_file() or checksum(dest, row.get('baseline_checksum', 'sha256-lf') == 'sha256-lf') not in row['allowed_text_sha256']:
            conflicts.append(row['path'])
    for row in manifest['files']:
        dest = safe_path(target, row['path'])
        if dest.exists() and (not dest.is_file() or checksum(dest, row.get('baseline_checksum', 'sha256-lf') == 'sha256-lf') not in row['allowed_text_sha256']):
            conflicts.append(row['path'])
    if conflicts:
        raise ValueError('Kode lokal berbeda atau dasar paket belum lengkap. Tidak ada file ditimpa:\n' +
                         '\n'.join(sorted(set(conflicts))))
    if stopped:
        require_stopped()
    report = probe_runtime(target) if runtime else {}
    changes = [row for row in manifest['files'] if not safe_path(target, row['path']).is_file()
               or checksum(safe_path(target, row['path'])) != row['sha256']]
    return manifest, changes, report


def rollback(target, backup=None, stopped=True,*,restore_project_state=False):
    target = target.resolve()
    if stopped:
        require_stopped()
    states = {'installed', 'prepared', 'restoring', 'rollback_required'}
    if backup is None:
        journals = sorted((target / 'steezy_backups').glob('complete-*/complete-backup.json'), reverse=True)
        journal = next((p for p in journals if json.loads(p.read_text(encoding='utf-8')).get('status') in states), None)
        if journal is None:
            raise ValueError('Cadangan Pembenahan Lengkap yang aktif tidak ditemukan.')
    else:
        journal = Path(backup).resolve() / 'complete-backup.json'
    record = json.loads(journal.read_text(encoding='utf-8'))
    if Path(record['target']).resolve() != target or record['status'] not in states:
        raise ValueError('Cadangan tidak sesuai target atau sudah dipulihkan.')
    database=record.get('database_backup') or {}
    current_database=Path(database.get('source',''))
    advanced=[]
    m5=record.get('version')=='4.0.16'
    baseline=str(record.get('baseline_version',''))
    supports_m2=m5 and baseline.startswith(('4.0.13','4.0.14','4.0.15','4.0.16'))
    supports_editor=m5 and baseline.startswith(('4.0.12','4.0.13','4.0.14','4.0.15','4.0.16'))
    supports_m4=m5 and baseline.startswith(('4.0.15','4.0.16'))
    supports_m3=record.get('version') in ('4.0.15','4.0.16') and baseline.startswith(('4.0.14','4.0.15','4.0.16'))
    if record.get('version') in ('4.0.12','4.0.13','4.0.14','4.0.15','4.0.16') and record['status']=='installed' and current_database.is_file():
        with sqlite3.connect(current_database.as_uri()+'?mode=ro',uri=True) as db:
            if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='projects'").fetchone():
                for project_id,document in db.execute('SELECT id,document FROM projects'):
                    value=json.loads(document)
                    if not (supports_m2 or supports_m3) and record.get('version') in ('4.0.13','4.0.14','4.0.15','4.0.16') and (any(value.get(k) for k in ('transcript_track_history','translation_tracks','translation_proposals','source_timing_overrides','clip_source_timing_overrides','variant_source_timing_overrides','variant_corrections','manual_speakers','diarization')) or value.get('source',{}).get('info',{}).get('kind')=='audio' or value.get('source',{}).get('lineage')):
                        advanced.append(project_id)
                    if not supports_m3 and record.get('version') in ('4.0.14','4.0.15','4.0.16') and (any(value.get(k) for k in ('selection3','selection3_history','m3_decisions','m3_feedback','m3_markers','m3_selected_set')) or any(c.get('created_from')=='M3' for c in value.get('clips',{}).values())):
                        advanced.append(project_id)
                    for clip in value.get('clips',{}).values():
                        for variant in clip.get('variants',{}).values():
                            editor=variant.get('editor',{})
                            if m5 and variant.get('finishing5'):advanced.append(project_id)
                            if record.get('version') in ('4.0.15','4.0.16') and not supports_m4 and any(variant.get(k) for k in ('camera4_report','camera4_controls','camera4_feedback','camera4_enabled','camera4_ratio')):advanced.append(project_id)
                            if not (supports_editor or supports_m3) and (editor.get('segments') or any(editor.get('curves',{}).values()) or editor.get('hidden_caption_word_ids') or any(r.get('mute') or r.get('solo') for r in editor.get('tracks',{}).values())):
                                advanced.append(project_id)
            if not (supports_m2 or supports_m3) and record.get('version') in ('4.0.13','4.0.14','4.0.15','4.0.16') and db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='m2_imports'").fetchone():
                if db.execute("SELECT 1 FROM m2_imports WHERE status IN ('queued','running') LIMIT 1").fetchone():advanced.append('antrean-impor-M2')
            if record.get('version') in ('4.0.14','4.0.15','4.0.16') and db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='jobs'").fetchone():
                if not supports_m3 and db.execute("SELECT 1 FROM jobs WHERE kind='selection_m3' AND status IN ('queued','running','cancel_requested') LIMIT 1").fetchone():advanced.append('antrean-seleksi-M3')
                if record.get('version') in ('4.0.15','4.0.16') and not supports_m4 and db.execute("SELECT 1 FROM jobs WHERE kind='camera_m4' AND status IN ('queued','running','cancel_requested') LIMIT 1").fetchone():advanced.append('antrean-kamera-M4')
            if m5:
                for table in ('assets5','asset_history5','kits5','kit_history5'):
                    if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone() and db.execute('SELECT 1 FROM '+table+' LIMIT 1').fetchone():advanced.append('data-M5-'+table)
                if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='jobs'").fetchone() and db.execute("SELECT 1 FROM jobs WHERE kind IN ('gallery_m5','cover_m5') AND status IN ('queued','running','cancel_requested') LIMIT 1").fetchone():advanced.append('antrean-M5')
        if advanced and not restore_project_state:
            raise ValueError('Proyek/antrean memakai data upgrade yang tidak dikenali kode lama. Kode dan data belum diubah. '
                'Jika ingin memulihkan versi lama, gunakan --rollback --restore-project-state. SQLite terbaru akan dicadangkan terpisah sebelum state pra-upgrade dipulihkan. Baca panduan milestone paket yang dipasang.')
    # Validate every original and current file before changing the first one.
    for row in record['files']:
        dest = safe_path(target, row['path'])
        if dest.exists() and not dest.is_file():
            raise ValueError('Path kode berubah menjadi folder; periksa dahulu: ' + row['path'])
        if row['existed']:
            old = safe_path(journal.parent / 'original', row['path'])
            if not old.is_file() or checksum(old) != row['original_sha256']:
                raise ValueError('Integritas cadangan gagal: ' + row['path'])
        current = checksum(dest) if dest.is_file() else None
        if current not in {row['sha256'], row['original_sha256']}:
            raise ValueError('File berubah setelah upgrade; simpan atau bandingkan dahulu: ' + row['path'])
    if advanced and restore_project_state:
        original_database=Path(database['copy'])
        if not original_database.is_file() or checksum(original_database)!=database['sha256']:
            raise ValueError('Cadangan SQLite pra-upgrade tidak valid; database terbaru tidak diubah.')
        checkpoint=journal.parent/'data'/'studio4-latest-before-rollback.sqlite3'
        if checkpoint.exists():raise ValueError('Checkpoint terbaru sudah ada; periksa cadangan sebelum mengulang pemulihan data.')
        with sqlite3.connect(current_database.as_uri()+'?mode=ro',uri=True) as source:
            with sqlite3.connect(checkpoint) as destination:
                source.backup(destination)
                if destination.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('Checkpoint SQLite terbaru belum valid')
        record['latest_project_checkpoint']={'path':str(checkpoint),'sha256':checksum(checkpoint)}
        atomic_json(journal,record)
        with sqlite3.connect(original_database.as_uri()+'?mode=ro',uri=True) as source:
            with sqlite3.connect(current_database) as destination:
                source.backup(destination)
                if destination.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('Pemulihan SQLite perlu ditinjau; checkpoint terbaru tersedia: '+str(checkpoint))
        record['project_state_restored']=True
        atomic_json(journal,record)
    record['status'] = 'restoring'; atomic_json(journal, record)
    for row in reversed(record['files']):
        dest = safe_path(target, row['path'])
        if row['existed']:
            if checksum(dest) != row['original_sha256']:
                atomic_copy(safe_path(journal.parent / 'original', row['path']), dest)
        else:
            dest.unlink(missing_ok=True)
    record['status'] = 'restored'; atomic_json(journal, record)
    if record.get('project_state_restored'):
        print('Kode dan state pra-upgrade dipulihkan. Pekerjaan terbaru tersedia utuh pada checkpoint: '+record['latest_project_checkpoint']['path'])
    else:print('Kode sebelum Pembenahan Lengkap berhasil dipulihkan. Data proyek tetap tersedia.')
    return journal.parent


def backup_project_database(target, backup, work_dir=None):
    # Resolve the same Config/.env as the application in its verified Python.
    database = Path(work_dir or target/'work').resolve() / 'studio4.sqlite3'
    if not database.is_file():
        return None
    destination = backup / 'data' / 'studio4-before.sqlite3'
    destination.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(database.as_uri() + '?mode=ro', uri=True) as source:
        with sqlite3.connect(destination) as copy:
            source.backup(copy)
            if copy.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                raise ValueError('Cadangan database belum lolos pemeriksaan integritas.')
    return {'source': str(database), 'copy': str(destination), 'sha256': checksum(destination)}


def install(target, package, dry_run=False):
    target, package = target.resolve(), package.resolve()
    manifest, changes, runtime = preflight(target, package)
    print(f"Target: {target}\nVersi paket: {manifest['version']}\nFile yang diperbarui: {len(changes)}")
    if manifest.get('installer_revision'):
        print('Revisi installer: ' + str(manifest['installer_revision']))
    for name in manifest.get('preserved_local_files', []):
        print('File lokal dipertahankan tanpa dibaca/ditimpa: ' + name)
    print('Pemeriksaan Python: ' + runtime.get('python', ''))
    if dry_run:
        print('Pemeriksaan lulus. Jalankan '+manifest.get('install_command','PASANG_PEMBENAHAN_LENGKAP.cmd')+' untuk memasang.'); return None
    if not changes:
        print('Paket ini sudah terpasang.'); return None
    backup = target / 'steezy_backups' / ('complete-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
    backup.mkdir(parents=True)
    records = []
    for row in changes:
        dest = safe_path(target, row['path']); existed = dest.is_file()
        if existed:
            atomic_copy(dest, safe_path(backup / 'original', row['path']))
        records.append({**row, 'existed': existed, 'original_sha256': checksum(dest) if existed else None})
    baseline_version=None
    if manifest['version'] in ('4.0.15','4.0.16'):
        for node in ast.parse((target/'clipper/pipeline.py').read_text(encoding='utf-8-sig')).body:
            if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='RENDER_VERSION' for t in node.targets) and isinstance(node.value,ast.Constant):baseline_version=node.value.value
    record = {'schema_version': 1, 'version': manifest['version'], 'source_commit': manifest['source_commit'],'baseline_version':baseline_version,
              'target': str(target), 'status': 'prepared', 'files': records,
              'database_backup': backup_project_database(target, backup, runtime.get('work_dir'))}
    journal = backup / 'complete-backup.json'; atomic_json(journal, record)
    try:
        # Detect edits made after the initial check and before the first copy.
        preflight(target, package)
        for row in records:
            dest = safe_path(target, row['path'])
            current = checksum(dest) if dest.is_file() else None
            if current != row['original_sha256']:
                raise ValueError('File berubah saat pemasangan: ' + row['path'])
            atomic_copy(safe_path(package / 'payload', row['path']), dest)
        probe_runtime(target, after=True)
        record['status'] = 'installed'; atomic_json(journal, record)
    except Exception:
        try:
            rollback(target, backup, stopped=False)
        except Exception as recovery:
            record['status'] = 'rollback_required'; atomic_json(journal, record)
            raise ValueError('Pemasangan gagal dan pemulihan perlu dilanjutkan. Cadangan: ' + str(backup) +
                             '. ' + str(recovery)) from recovery
        raise
    print('Pemasangan selesai. Cadangan kode: ' + str(backup))
    print('Jalankan JALANKAN_PRO.cmd pada mesin lama, lalu Ctrl+F5 di browser.')
    return backup


def main():
    parser = argparse.ArgumentParser(description='Pemasang offline Clipper Studio Pembenahan Lengkap')
    parser.add_argument('--target'); parser.add_argument('--package')
    parser.add_argument('--check', action='store_true'); parser.add_argument('--rollback', action='store_true')
    parser.add_argument('--backup', help='Folder cadangan tertentu untuk dipulihkan')
    parser.add_argument('--restore-project-state',action='store_true',help='Saat rollback, cadangkan SQLite terbaru lalu pulihkan state pra-upgrade jika memakai edit M1 lanjutan')
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        raise ValueError('Gunakan Python 3.10 atau lebih baru.')
    default = Path(r'C:\AI\clipper')
    raw = args.target or (str(default) if default.is_dir() else input('Folder mesin lama (contoh C:\\AI\\clipper): '))
    target = Path(raw.strip().strip('"')).resolve()
    if args.rollback:
        rollback(target, args.backup,restore_project_state=args.restore_project_state)
    else:
        package = Path(args.package).resolve() if args.package else Path(__file__).resolve().parent
        install(target, package, dry_run=args.check)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        print('GAGAL: ' + str(exc), file=sys.stderr); sys.exit(1)
